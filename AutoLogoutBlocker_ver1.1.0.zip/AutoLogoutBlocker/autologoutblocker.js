property.pathnames['403'] = "#";
property.pathnames['500'] = "#";
console.log(property.pathnames['403']);
console.log(property.pathnames['500']);
